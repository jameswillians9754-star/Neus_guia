# PROJECT_STATUS — NEXUS EBOOKS

## Objectivo
Site responsivo mobile-first para promover ebooks de Desenvolvimento Pessoal e Negócios via links de afiliados EscalePay.

## Implementado
- 8 páginas: index, catalogo, categorias, ebook (detalhes), sobre, contacto, faq, 404.
- 22 ebooks com links de checkout reais integrados.
- Cartões com botão "VER EBOOK" directo ao checkout + botão "Ver detalhes".
- Páginas individuais com mockup grande, descrição, benefícios, para quem é útil e botão "COMPRAR AGORA".
- Menu fixo (Início, Ebooks, Contacto) com versão móvel hambúrguer.
- Pesquisa por título e filtro por categoria funcionais.
- Animações suaves de scroll (IntersectionObserver, com respeito a prefers-reduced-motion).
- Capas tipográficas com cores por tema; favicon; SEO básico; acessibilidade.

## Pendências
- Descrições oficiais dos ebooks (needsConfirmation: true).
- Email/canais de contacto confirmados.
- Publicação (Netlify Drop / GitHub Pages / Vercel).

## Executar
cd workspace && python3 -m http.server 8000 → http://localhost:8000

## Próximo passo
Publicar via Netlify Drop e confirmar link público.
