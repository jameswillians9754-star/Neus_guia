function catName(id){const c=CATEGORIES.find(c=>c.id===id);return c?c.name:"Outros";}
function coverStyle(b){const h=Math.round(((b.id-1)*137.5)%360);return `background:linear-gradient(160deg,hsl(${h} 45% 20%),hsl(${(h+25)%360} 50% 32%))`;}
function coverHTML(book,extra){if(book.image)return `<div class="book-cover has-img ${extra||""}"><img src="${book.image}" alt="Capa do ebook ${book.title}" loading="lazy" decoding="async"></div>`;return `<div class="book-cover theme-${book.cover.theme} ${extra||""}" style="${coverStyle(book)}" role="img" aria-label="Capa do ebook ${book.title}"><span class="brand">Nexus Ebooks</span><span class="title">${book.title}</span><span class="rule"></span></div>`;}
function cardHTML(b){return `<article class="card reveal"><a href="ebook.html?id=${b.slug}" aria-label="Ver detalhes de ${b.title}">${coverHTML(b)}</a><div class="card-body"><span class="tag">${catName(b.category)}</span><h3>${b.title}</h3><p class="desc">${b.shortDescription}</p><a class="btn btn-primary btn-block" href="${b.affiliateUrl}" target="_blank" rel="noopener noreferrer sponsored">VER EBOOK</a><a class="btn btn-outline btn-block" href="ebook.html?id=${b.slug}">Ver detalhes</a></div></article>`;}
function initHeader(){
const page=document.body.dataset.page||"";
const links=[["index.html","Início","home"],["catalogo.html","Ebooks","catalog"],["contacto.html","Contacto","contact"]];
const desk=links.map(l=>`<a href="${l[0]}"${page===l[2]?' aria-current="page"':""}>${l[1]}</a>`).join("");
const mob=links.map(l=>`<a href="${l[0]}"${page===l[2]?' aria-current="page"':""}>${l[1]}</a>`).join("");
document.getElementById("site-header").innerHTML=`<div class="container header-inner"><a class="logo" href="index.html">NEXUS<span>EBOOKS</span></a><nav class="nav-desktop" aria-label="Navegação principal">${desk}</nav><div class="header-actions"><a class="icon-btn" href="catalogo.html" aria-label="Ver ebooks"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg></a><button class="icon-btn menu-btn" id="menuBtn" aria-expanded="false" aria-controls="mobileNav" aria-label="Abrir menu"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 7h16M4 12h16M4 17h16"/></svg></button></div></div><nav class="mobile-nav" id="mobileNav" aria-label="Navegação móvel">${mob}</nav>`;
const btn=document.getElementById("menuBtn"),nav=document.getElementById("mobileNav");
btn.addEventListener("click",()=>{const o=nav.classList.toggle("open");btn.setAttribute("aria-expanded",o);});}
function initFooter(){
document.getElementById("site-footer").innerHTML=`<div class="container"><div class="footer-grid"><div class="footer-brand"><a class="logo" href="index.html" style="color:#fff">NEXUS<span>EBOOKS</span></a><p>Montra digital de ebooks sobre desenvolvimento pessoal, negócios, finanças, tecnologia e mais.</p></div><div class="footer-col"><h3>Navegação</h3><a href="index.html">Início</a><a href="catalogo.html">Ebooks</a><a href="contacto.html">Contacto</a></div><div class="footer-col"><h3>Apoio</h3><a href="faq.html">Perguntas frequentes</a><a href="sobre.html">Sobre</a><a href="catalogo.html">Explorar ebooks</a><a href="mailto:nexusguia001@gmail.com">nexusguia001@gmail.com</a></div></div><div class="footer-bottom"><span>© ${new Date().getFullYear()} NEXUS EBOOKS</span><span>As compras e entregas são processadas pelas plataformas de afiliados.</span></div></div>`;}
function initReveal(){
const els=document.querySelectorAll(".reveal");
if(!("IntersectionObserver" in window)){els.forEach(e=>e.classList.add("visible"));return;}
const io=new IntersectionObserver(entries=>{entries.forEach(en=>{if(en.isIntersecting){en.target.classList.add("visible");io.unobserve(en.target);}});},{threshold:.08});
els.forEach(e=>io.observe(e));}
document.addEventListener("DOMContentLoaded",()=>{initHeader();initFooter();initReveal();});

/* transições entre páginas */
document.addEventListener("click",e=>{const a=e.target.closest("a[href]");if(!a||a.target==="_blank"||e.metaKey||e.ctrlKey||e.shiftKey)return;const u=new URL(a.href,location.href);if(u.origin!==location.origin||(u.pathname===location.pathname&&u.hash))return;if(matchMedia("(prefers-reduced-motion: reduce)").matches)return;e.preventDefault();document.body.classList.add("leaving");setTimeout(()=>{location.href=a.href;},220);});
window.addEventListener("pageshow",e=>{if(e.persisted)document.body.classList.remove("leaving");});
